//
//  SegundoViewController.swift
//  Proyecto02
//
//  Created by Macbook on 3/8/19.
//  Copyright © 2019 AcuaMod. All rights reserved.
//

import UIKit

class SegundoViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func X() {
        dismiss(animated: true, completion: nil)
    }
}
